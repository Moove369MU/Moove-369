import { db, auth } from "./firebase.js"; // ajusta o caminho se necessário

document.addEventListener("DOMContentLoaded", () => {
  const logo = document.getElementById("logo");
  const btnGroup = document.getElementById("btnGroup");

  // Aparecer o logo com fade-in
  setTimeout(() => {
    logo.classList.add("fade-in");
  }, 500);

  // Aparecer os botões depois de 2.5s
  setTimeout(() => {
    btnGroup.classList.remove("hidden");
  }, 2500);
});
