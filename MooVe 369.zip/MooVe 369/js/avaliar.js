function enviarAvaliacao() {
  const nota = document.querySelector('input[name="estrela"]:checked');
  const comentario = document.getElementById("comentario").value.trim();

  if (!nota) {
    alert("Por favor, selecione uma nota.");
    return false;
  }

  const dados = {
    nota: parseInt(nota.value),
    comentario,
    passageiroID: "user123", // substitua por ID real
    motoristaID: "driver456", // opcional
    dataHora: new Date().toISOString()
  };

  db.collection("avaliacoes").add(dados)
    .then(() => {
      alert("Avaliação enviada com sucesso!");
      window.location.href = "painel-passageiro.html"; // ou qualquer tela seguinte
    })
    .catch((error) => {
      console.error("Erro ao enviar avaliação:", error);
      alert("Erro ao enviar. Tente novamente.");
    });

  return false; // evita reload
}
