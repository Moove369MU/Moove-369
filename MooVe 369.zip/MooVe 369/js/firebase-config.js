// js/firebase-config.js

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyAglJndlz2O7N0_eSShytlF2cDGS5p8f8Y",
  authDomain: "moove-369.firebaseapp.com",
  projectId: "moove-369",
  storageBucket: "moove-369.firebasestorage.app",
  messagingSenderId: "558066610093",
  appId: "1:558066610093:web:622ffb4f04ca7de02fbb24",
  measurementId: "G-M4B72QM1DG"
};

// Inicializar Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

export { app, auth, db };
