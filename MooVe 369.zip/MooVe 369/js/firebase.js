// Importa os SDKs necessários
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.10.0/firebase-app.js";
import { getDatabase } from "https://www.gstatic.com/firebasejs/11.10.0/firebase-database.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/11.10.0/firebase-auth.js";

// Configuração do Firebase
const firebaseConfig = {
  apiKey: "AIzaSyAglJndlz2O7N0_eSShytlF2cDGS5p8f8Y",
  authDomain: "moove-369.firebaseapp.com",
  projectId: "moove-369",
  storageBucket: "moove-369.firebasestorage.app",
  messagingSenderId: "558066610093",
  appId: "1:558066610093:web:622ffb4f04ca7de02fbb24",
  measurementId: "G-M4B72QM1DG"
};

// Inicializa o app
const app = initializeApp(firebaseConfig);

// Exporta para ser usado em outros arquivos
export const db = getDatabase(app);
export const auth = getAuth(app);
