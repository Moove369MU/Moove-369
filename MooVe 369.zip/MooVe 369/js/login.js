document.addEventListener("DOMContentLoaded", () => {
  const title = document.getElementById("loginTitle");
  const criarConta = document.getElementById("criarConta");
  const urlParams = new URLSearchParams(window.location.search);
  const tipo = urlParams.get("tipo");

  if (tipo === "motorista") {
    title.textContent = "Login do Motorista";
    criarConta.href = "../cadastro.html?tipo=motorista";
  } else {
    title.textContent = "Login do Passageiro";
    criarConta.href = "../cadastro.html?tipo=passageiro";
  }

  // Manipula o envio do formulário
  const form = document.querySelector(".login-form");
  form.addEventListener("submit", (e) => {
    e.preventDefault();

    const cpf = document.getElementById("cpf").value.trim();
    const senha = document.getElementById("senha").value.trim();

    if (cpf === "" || senha === "") {
      alert("Preencha todos os campos.");
      return;
    }

    // Aqui você pode futuramente validar com backend

    // Salva o tipo de usuário no localStorage
    localStorage.setItem("tipoUsuario", tipo || "passageiro");

    // Redireciona para a tela de agradecimento
    window.location.href = "agradecimento.html";
  });
});
