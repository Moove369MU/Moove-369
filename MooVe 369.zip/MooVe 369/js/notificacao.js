function mostrarNotificacao(mensagem) {
  let notificacao = document.createElement('div');
  notificacao.className = 'notificacao-moove';
  notificacao.innerText = mensagem;

  document.body.appendChild(notificacao);

  // Som de notificação (pequeno beep embutido como base64)
  const beep = new Audio("data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAIlYAAESsAAACABAAZGF0YVwAAAAA//8AAP//AAD//wAA//8AAP//AAD//wAA");
  beep.play();

  // Animação de entrada
  setTimeout(() => {
    notificacao.classList.add('visivel');
  }, 100);

  // Esconder após 4 segundos
  setTimeout(() => {
    notificacao.classList.remove('visivel');
    setTimeout(() => document.body.removeChild(notificacao), 500);
  }, 4000);
}
