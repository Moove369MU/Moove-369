function confirmarRota() {
  const origem = document.getElementById('origem').value.trim();
  const destino = document.getElementById('destino').value.trim();

  if (origem === '' || destino === '') {
    alert('Por favor, preencha origem e destino.');
    return;
  }

  alert(`🚕 Pedido enviado!\nOrigem: ${origem}\nDestino: ${destino}`);

  // Redireciona para rota.html
  window.location.href = 'rota.html';
}
